import * as server from "minimalistic-server";
import * as fsAdapter from "./fs-adapter.mjs";
import * as nodeCrypto from "node:crypto";

if (process.env.DATABASE_URL) {
	server.setServerFsPromiseModule(await fsAdapter.getAdapter());
}

let users = [];
let counter = Date.now() % 10000;
let lockPromiseWithResolvers = null;

async function lock() {
	await lockPromiseWithResolvers?.promise;
	lockPromiseWithResolvers = Promise.withResolvers();
}

function unlock() {
	lockPromiseWithResolvers?.resolve();
	lockPromiseWithResolvers = null;
}

async function exists(f) {
	try {
		await server.getServerFsPromiseModule().stat(f);
		return true;
	} catch {
		return false;
	}
}

if (!(await exists('db'))) {
	await server.getServerFsPromiseModule().mkdir('db');
}

if (await exists('db/db.json')) {
	({ users, counter } = JSON.parse(await server.getServerFsPromiseModule().readFile('db/db.json')));
} else {
	await saveData();
}

if (!(await exists('files'))) {
	await server.getServerFsPromiseModule().mkdir('files');
}

function generateId() {
	return `R${crypto.randomUUID()}-${++counter}`;
}

async function generateToken(user) {
	const salt = crypto.randomUUID();
	const hash = await getHash(user.password, salt);

	return btoa(JSON.stringify({
		id: user.id,
		salt,
		hash,
	}));
}

function hashThePassword(password) {
	return nodeCrypto.hash('sha512', password);
}

async function getHash(password, salt) {
	return new Promise((resolve, reject) => {
		nodeCrypto.pbkdf2(password, salt, 10000, 64, 'sha512', (error, buffer) => {
			if (error) {
				reject(error);
			} else {
				resolve(buffer.toString('hex'));
			}
		});
	});
}

async function saveData() {
	await server.getServerFsPromiseModule().writeFile('db/db.json', JSON.stringify({ users, counter }));
}

async function deleteImageFile(image) {
	try {
		await server.getServerFsPromiseModule().unlink(image.serverFilePath);
	} catch (error) {
		console.error(error);

		for (let i = 0; i < 30; ++i) {
			server.blockStaticCache(image.serverFilePath);
			await new Promise((resolve => setTimeout(resolve, 1000)));

			try {
				await server.getServerFsPromiseModule().unlink(image.serverFilePath);
				break;
			} catch (error) {
				console.error(error);
			}
		}
	}

	server.clearStaticCache(image.serverFilePath);
}


///////////////////////////////////////////

export async function getUserByToken(token) {
	if (!token) {
		return;
	}

	try {
		const {
			id,
			salt,
			hash,
		} = JSON.parse(atob(token));

		const user = users.find(u => u.id === id);

		if (user && (await getHash(user.password, salt)) === hash) {
			return user;
		}
	} catch (e) {
		console.error(e);
	}

}

export async function loginUser(username, password) {
	password = hashThePassword(password);

	const user = users.find(u => u.username === username && u.password === password);

	if (!user) {
		throw new Error('Wrong username or password');
	}

	return await generateToken(user);
}

export async function registerUser(username, password) {
	try {
		await lock();

		const existingUser = users.find(u => u.username === username);

		if (existingUser) {
			throw new Error('A user with such username already exists');
		}

		password = hashThePassword(password);

		const newUser = {
			id: generateId(),
			username,
			password,
			images: [],
		};

		users.push(newUser);
		await saveData();
		return await generateToken(newUser);
	} finally {
		unlock();
	}
}

export async function addImages(user, uploads) {
	try {
		await lock();

		const maxNewUploads = 50 - user.images.length;
		const statuses = await Promise.allSettled(uploads.slice(0, maxNewUploads).map(async up => {
			const id = generateId();
			const extension = up.getExtension();
			const url = `/data/${id}.${extension}`;
			const serverFilePath = `files/${id}.${extension}`;

			await server.getServerFsPromiseModule().writeFile(serverFilePath, up.getContent());
			server.clearStaticCache(serverFilePath);

			return {
				id,
				url,
				serverFilePath,
				isVideo: up.getContentTypeByExtension().startsWith('video/'),
				isAudio: up.getContentTypeByExtension().startsWith('audio/'),
			}
		}));

		for (const status of statuses) {
			if (status.status === 'fulfilled') {
				user.images.push(status.value);
			} else {
				console.error('Error uploading file', status.reason);
			}
		}

		await saveData();

		return user.images.at(-1) ? `#${user.images.at(-1).id}` : '';
	} finally {
		unlock();
	}
}

export async function deleteUser(user) {
	try {
		await lock();
		await Promise.all(user.images.map(im => deleteImageFile(im)));
		users = users.filter(u => u !== user);
		await saveData();
	} finally {
		unlock();
	}
}

export async function deleteImage(user, imageId) {
	try {
		await lock();
		const image = user.images.find(im => im.id === imageId);

		if (!image) {
			return '';
		}

		const imageToFocus = user.images.at(user.images.indexOf(image) + 1) ?? user.images.at(user.images.indexOf(image) - 1);

		await deleteImageFile(image);
		user.images = user.images.filter(im => im !== image);

		await saveData();

		return imageToFocus && imageToFocus !== image ? `#${imageToFocus.id}` : '';
	} finally {
		unlock();
	}
}

export async function changePassword(user, oldPassword, newPassword) {
	oldPassword = hashThePassword(oldPassword);
	newPassword = hashThePassword(newPassword);

	if (user.password !== oldPassword) {
		throw new Error('Wrong current password');
	}

	try {
		await lock();
		user.password = newPassword;
		await saveData();
		return await generateToken(user);
	} finally {
		unlock();
	}
}