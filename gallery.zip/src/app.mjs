
import * as server from "minimalistic-server";
import * as controllers from "./controllers.mjs";

server.serve(
	{
		preMiddlewares: [
			(request) => {
				const pathAndQuery = request.getRawUrl()?.split('?', 2) ?? [];

				const normalizedPath = `/${pathAndQuery[0].split('/').filter(x => x).join('/')}`;

				if (normalizedPath === pathAndQuery[0]) {
					return;
				}

				pathAndQuery[0] = normalizedPath;

				throw new server.RedirectResponse(pathAndQuery.join('?'));
			}
		],
		'test-cache': () => {
			return {
				date: new Date(),
			}
		},
		'test-ws': (request) => {
			const { write, close } = request.handleAsWebSocket((message, type) => {
				if (type === 'start') {
					write('Hello from server');
					return;
				}

				if (type === 'message') {
					if (+message < 0.1) {
						close();
						return;
					} else {
						write(Math.random());
					}
				}

				if (type === 'end') {
					console.log(type);
				}
			});
		},
		'': {
			preMiddlewares: [
				controllers.authorizeUser
			],
			'': controllers.getMainPage,
			'logout': {
				post: controllers.logoutUser,
			},
			'delete-self': {
				post: controllers.deleteSelf,
			},
			'add-images': {
				post: controllers.addImages,
			},
			'delete-image/{imageId}': {
				post: controllers.deleteImage,
			},
			'change-password': {
				get: controllers.getChangePasswordPage,
				post: controllers.postChangePasswordPage,
			},
		},
		'login': {
			get: controllers.getLoginPage,
			post: controllers.postLoginPage,
		},
		'register': {
			get: controllers.getRegisterPage,
			post: controllers.postRegisterPage,
		}
	},
	process.env.PORT || 80,
	[
		{
			urlPath: 'data',
			serverFilePath: 'files',
			showWholeDirectory: false,
		},
		{
			urlPath: 'static',
			serverFilePath: 'resources',
			showWholeDirectory: true,
		}
	], controllers.onNotFound,
);