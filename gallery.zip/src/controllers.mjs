import * as service from "./service.mjs";
import * as server from "minimalistic-server";
const now = Date.now();

function assemblePageHtml(contentHtml, title = 'Gallery') {
	return `<!DOCTYPE html>
<html lang="en">
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>${server.escapeHtml(title)}</title>
<link rel="icon" href="/static/icons/favicon.png?v=${now}">
<link rel="stylesheet" href="/static/css/style.css?v=${now}">
<script type="module" src="/static/js/script.js?v=${now}"></script>
</head>
<body>
${contentHtml}
</body>

</html>
`;
}

export async function authorizeUser(request) {
	const user = await service.getUserByToken(request.getCookies()['token']);

	if (!user) {
		throw new server.RedirectResponse(`/login?errorMessage=${encodeURIComponent('Not authorized, please log in')}`);
	}

	request.setCustomData(user);
}

export async function logoutUser() {
	return new server.RedirectResponse(`/login`, 301, {
		'token': null,
	});
}

export function getMainPage(request) {
	const user = request.getCustomData();

	const blockTemplate = `<div class="image-block" id="RESOURCE_ID">
		IMAGE_OR_VIDEO_HTML
		<div class="row">
			<button type="button" class="f_copyToClipboard">Copy URL to clipboard</button>
			<button formaction="/delete-image/RESOURCE_ID">Delete</button>
		</div>
	</div>`;

	const imageBlockTemplate = blockTemplate.replaceAll('IMAGE_OR_VIDEO_HTML', `<img loading="lazy" alt="Image" src="RESOURCE_URL">`);
	const videoBlockTemplate = blockTemplate.replaceAll('IMAGE_OR_VIDEO_HTML', `<video src="RESOURCE_URL" controls></video>`);
	const audioBlockTemplate = blockTemplate.replaceAll('IMAGE_OR_VIDEO_HTML', `<audio src="RESOURCE_URL" controls></audio>`);

	return assemblePageHtml(
		`
		<form method="post" class="long">
		<div class="row head">
			<h1>Hi, ${server.escapeHtml(user.username)}</h1>
			<a href="/change-password">Change password</a>
			<button formaction="/delete-self">Delete self</button>
			<button formaction="/logout">Logout</button>
		</div>
		<hr>

		${user.images.length ?
			`
			<div class="images-container">
				<template id="imageBlockTemplate">${imageBlockTemplate}</template>
				<template id="videoBlockTemplate">${videoBlockTemplate}</template>
				<template id="audioBlockTemplate">${audioBlockTemplate}</template>
				${user.images.map(im =>
				(im.isVideo ? videoBlockTemplate : (im.isAudio ? audioBlockTemplate : imageBlockTemplate))
					.replaceAll('RESOURCE_ID', im.id)
					.replaceAll('RESOURCE_URL', im.url)
			).join('')}
			</div>
			` :
			'<div class="row">No items to show</div>'}

		<hr>
		</form>
		<br>
		<form ${user.images.length < 50 ? '' : 'style="display: none"'} method="post" id="uploadForm" action="/add-images" enctype="multipart/form-data">
			<label>Medias:<input type="file" name="images[]" multiple required accept="image/*,video/*,audio/*,.mkv"></label>
			<div class="row">
				<button>Submit</button>
			</div>
		</form>`,
	)
}

export function getLoginPage(request) {
	const errorMessage = request.getQueryParams().errorMessage ?? '';
	const isInvaid = request.getQueryParams().isInvaid === '1';

	return new server.HTMLResponse(assemblePageHtml(
		`
		<form method="post">
		<div class="error-message">${server.escapeHtml(errorMessage)}</div>
		<label>Username:<input type="text" name="username" required></label>
		<label>Password:<input type="password" name="password" required></label>

		<div class="row">
			<button>Login</button>
			<a href="/register">Or register</a>
		</div>

		</form>
		`, 'Login'
	), errorMessage ? (isInvaid ? 400 : 401) : 200);
}

export async function postLoginPage(request) {
	const body = await request.getBody();

	try {
		const token = await service.loginUser(`${body.username}`, `${body.password}`);
		return new server.RedirectResponse(`/`, 301, {
			'token': {
				httpOnly: true,
				value: token,
			}
		});
	} catch (e) {
		throw new server.RedirectResponse(`/login?errorMessage=${encodeURIComponent(e.message)}`);
	}
}

export function getRegisterPage(request) {
	const errorMessage = request.getQueryParams().errorMessage ?? '';
	const isInvaid = request.getQueryParams().isInvaid === '1';

	return new server.HTMLResponse(assemblePageHtml(
		`
		<form method="post">
		<div class="error-message">${server.escapeHtml(errorMessage)}</div>
		<label>Username:<input type="text" name="username" required></label>
		<label>Password:<input type="password" name="password" required></label>
		<label>Confirm password:<input type="password" name="confirmPassword" required></label>

		<div class="row">
			<button>Register</button>
			<a href="/login">Or login</a>
		</div>

		</form>
		`, 'Register'
	), errorMessage ? (isInvaid ? 400 : 409) : 200);
}

export async function postRegisterPage(request) {
	const body = await request.getBody();

	if (
		typeof body.username !== 'string' || !body.username ||
		typeof body.password !== 'string' || !body.password ||
		typeof body.confirmPassword !== 'string' || !body.confirmPassword
	) {
		throw new server.RedirectResponse(`/register?errorMessage=${encodeURIComponent(`Please fill all fields`)}&isInvaid=1`);
	}

	if (body.password !== body.confirmPassword) {
		throw new server.RedirectResponse(`/register?errorMessage=${encodeURIComponent(`Passwords do not match`)}&isInvaid=1`);
	}

	if (!body.username.match(/^[A-Za-z_]{3,30}$/gm)) {
		throw new server.RedirectResponse(`/register?errorMessage=${encodeURIComponent(`The username must be composed from 3-30 english letters or underlines`)}&isInvaid=1`);
	}

	if (!body.password.match(/^\S{8,30}$/gm)) {
		throw new server.RedirectResponse(`/register?errorMessage=${encodeURIComponent(`The password must be composed from 8-30 non space characters`)}&isInvaid=1`);
	}

	try {
		const token = await service.registerUser(body.username, body.password);
		return new server.RedirectResponse(`/`, 301, {
			'token': {
				httpOnly: true,
				value: token,
			}
		});
	} catch (e) {
		throw new server.RedirectResponse(`/register?errorMessage=${encodeURIComponent(e.message)}`);
	}
}

export async function deleteSelf(request) {
	const user = request.getCustomData();
	await service.deleteUser(user);

	return new server.RedirectResponse(`/register`, 301, {
		'token': null,
	});
}

export async function deleteImage(request) {
	const user = request.getCustomData();
	const imageId = request.getPathParams().imageId;
	const hash = await service.deleteImage(user, imageId);

	if (request.getQueryParams()['isJson'] === '1') {
		return getUserDataJson(user);
	}

	return new server.RedirectResponse(`/${hash}`);
}

export async function addImages(request) {
	const user = request.getCustomData();
	let { images } = await request.getBody();

	if (!(images instanceof Array)) {
		return new server.RedirectResponse(`/`);
	}

	images = images.filter(
		im => im instanceof server.UploadedFile && (
			im.getContentTypeByExtension().startsWith('image/') ||
			im.getContentTypeByExtension().startsWith('video/') ||
			im.getContentTypeByExtension().startsWith('audio/')
		)
	);

	const hash = await service.addImages(user, images);

	if (request.getQueryParams()['isJson'] === '1') {
		return getUserDataJson(user);
	}

	return new server.RedirectResponse(`/${hash}`);
}

export function getChangePasswordPage(request) {
	const errorMessage = request.getQueryParams().errorMessage ?? '';
	const isInvaid = request.getQueryParams().isInvaid === '1';

	return new server.HTMLResponse(assemblePageHtml(
		`
		<form method="post">
		<div class="error-message">${server.escapeHtml(errorMessage)}</div>
		<label>Old password:<input type="password" name="oldPassword" required></label>
		<label>New password:<input type="password" name="newPassword" required></label>
		<label>Confirm password:<input type="password" name="confirmPassword" required></label>

		<div class="row">
			<button>Change password</button>
			<a href="/">Or go back</a>
		</div>

		</form>
		`, 'Change password'
	), errorMessage ? (isInvaid ? 400 : 401) : 200);
}

export async function postChangePasswordPage(request) {
	const user = request.getCustomData();
	const body = await request.getBody();

	if (
		typeof body.oldPassword !== 'string' || !body.oldPassword ||
		typeof body.newPassword !== 'string' || !body.newPassword ||
		typeof body.confirmPassword !== 'string' || !body.confirmPassword
	) {
		throw new server.RedirectResponse(`/change-password?errorMessage=${encodeURIComponent(`Please fill all fields`)}&isInvaid=1`);
	}

	if (body.newPassword !== body.confirmPassword) {
		throw new server.RedirectResponse(`/change-password?errorMessage=${encodeURIComponent(`Passwords do not match`)}&isInvaid=1`);
	}

	if (!body.newPassword.match(/^\S{8,30}$/gm)) {
		throw new server.RedirectResponse(`/change-password?errorMessage=${encodeURIComponent(`The password must be composed from 8-30 non space characters`)}&isInvaid=1`);
	}

	try {
		const token = await service.changePassword(user, body.oldPassword, body.newPassword);
		return new server.RedirectResponse(`/`, 301, {
			'token': {
				httpOnly: true,
				value: token,
			}
		});
	} catch (e) {
		throw new server.RedirectResponse(`/change-password?errorMessage=${encodeURIComponent(e.message)}`);
	}
}

function getUserDataJson(user) {
	return {
		id: user.id,
		username: user.username,
		images: user.images.map(im => ({
			...im,
			serverFilePath: undefined,
		})),
	}
}

export function onNotFound(request) {
	return new server.HTMLResponse(assemblePageHtml(`<h1>Oops,</h1>
		<h2>resource <i style="color: yellow;">${server.escapeHtml(request.getRawUrl())}</i> was not found</h2>		<img alt="Not found" src="/static/icons/not-found.png">
`, 'Page not found'), 404);
}