import * as fs from "node:fs/promises";
import pg from 'pg';

const client = new pg.Client({
	connectionString: process.env.DATABASE_URL,
	ssl: {
		rejectUnauthorized: false,
	}
});

export async function getAdapter() {
	await client.connect();

	await client.query(`CREATE TABLE IF NOT EXISTS "db_files" (
		"path" varchar(255) NOT NULL,
		"name" varchar(255) NOT NULL,
		"content" BYTEA,
		PRIMARY KEY ("path", "name")
	);`);

	return {
		stat,
		mkdir,
		readFile,
		writeFile,
		unlink,
		readdir,
		open,
	};
}

function normalizePath(path) {
	return path?.split('/').filter(x => x).join('/') ?? '';
}

function isStatic(path) {
	path = normalizePath(path);
	return path === 'resources' || path.startsWith('resources/');
}

function getNameAndPath(path) {
	const res = {
		name: '',
		path: '',
	};

	normalizePath(path).split('/').forEach((v, i, a) => {
		if (i === a.length - 1) {
			res.name = v;
		} else {
			if (i) {
				res.path += '/';
			}

			res.path += v;
		}
	});

	return res;
}

async function stat(path, ...otherParams) {
	if (isStatic(path)) {
		return fs.stat(path, ...otherParams);
	}
	///////////////////////////////////
	const nameAndPath = getNameAndPath(path);

	const result = await client.query(
		`SELECT 
				LENGTH("content") AS "size", 
				"content" IS NULL AS "isDir" 
		FROM "db_files"
		WHERE "name" = $1 AND "path" = $2;
		`, [nameAndPath.name, nameAndPath.path]);

	if (!result.rowCount) {
		throw new Error(`File/folder not found: ${path}`);
	}

	return {
		isDirectory() {
			return !this.isFile();
		},
		isFile() {
			return !result.rows[0].isDir;
		},
		size: result.rows[0].size ?? 0,
	}
}

async function getPathStatus(path) {
	const nameAndPath = getNameAndPath(path);

	if (!nameAndPath.name) {
		return 'directory'
	}

	const result = await client.query(
		`SELECT 
				"content" IS NULL AS "isDir" 
		FROM "db_files"
		WHERE "name" = $1 AND "path" = $2;
		`, [nameAndPath.name, nameAndPath.path]);

	if (!result.rowCount) {
		return null;
	}

	return result.rows[0].isDir ? 'directory' : 'file';
}

async function mkdir(path, ...otherParams) {
	if (isStatic(path)) {
		return fs.mkdir(path, ...otherParams);
	}
	///////////////////////////////////
	path = normalizePath(path);

	if (!path) {
		return;
	}

	const nameAndPath = getNameAndPath(path);

	if ((await getPathStatus(nameAndPath.path)) !== 'directory') {
		throw new Error(`Directory doesn't exist: ${nameAndPath.path}`);
	}

	const status = await getPathStatus(path);

	if (status === 'directory') {
		return;
	}

	if (status === 'file') {
		throw new Error(`Can't overwrite on a file`);
	}

	await client.query(`INSERT INTO "db_files" ("name", "path")
		VALUES ($1, $2);`, [nameAndPath.name, nameAndPath.path],
	)
}

async function readFile(path, ...otherParams) {
	if (isStatic(path)) {
		return fs.readFile(path, ...otherParams);
	}
	///////////////////////////////////
	const nameAndPath = getNameAndPath(path);

	const result = await client.query(
		`SELECT *
			FROM "db_files"
			WHERE "name" = $1 AND "path" = $2 AND "content" IS NOT NULL;
		`, [nameAndPath.name, nameAndPath.path]);

	if (!result.rowCount) {
		throw new Error(`File not found: ${path}`);
	}

	return result.rows[0].content;
}

async function writeFile(path, content, ...otherParams) {
	if (isStatic(path)) {
		return fs.writeFile(path, content, ...otherParams);
	}
	///////////////////////////////////
	path = normalizePath(path);

	if (!path) {
		throw new Error(`Can't overwrite on the root directory`);
	}

	const nameAndPath = getNameAndPath(path);

	if ((await getPathStatus(nameAndPath.path)) !== 'directory') {
		throw new Error(`Directory doesn't exist: ${nameAndPath.path}`);
	}

	const status = await getPathStatus(path);

	if (status === 'directory') {
		throw new Error(`Can't overwrite on a directory`);
	}

	if (!(content instanceof Buffer)) {
		content = Buffer.from(content, 'utf8');
	}

	if (status === 'file') {
		await client.query(`UPDATE "db_files"
			SET "content" = $3
			WHERE "name" = $1 AND "path" = $2;`, [nameAndPath.name, nameAndPath.path, content],
		)
	} else {
		await client.query(`INSERT INTO "db_files" ("name", "path", "content")
			VALUES ($1, $2, $3);`, [nameAndPath.name, nameAndPath.path, content],
		)
	}
}

async function unlink(path) {
	if (isStatic(path)) {
		return fs.unlink(path);
	}
	///////////////////////////////////
	const normalizedPath = normalizePath(path);
	const nameAndPath = getNameAndPath(path);
	await client.query(
		`DELETE FROM "db_files"
			WHERE  "path" LIKE $1 OR "name" = $2 AND "path" = $3;
		`, [normalizedPath + '%', nameAndPath.name, nameAndPath.path]);
}

async function readdir(path, ...otherParams) {
	if (isStatic(path)) {
		return fs.readdir(path, ...otherParams);
	}
	///////////////////////////////////
	const normalizedPath = normalizePath(path);

	const result = await client.query(
		`SELECT "name"
			FROM "db_files"
			WHERE "path" = $1;
		`, [normalizedPath]);

	return result.rows.map(x => x.name);
}

async function open(path, ...otherParams) {
	if (isStatic(path)) {
		return fs.open(path, ...otherParams);
	}
	///////////////////////////////////
	const status = await stat(path);

	let pos = 0;

	return {
		stat() {
			return status;
		},
		async read(buf, offset = null, length = null, position = null) {
			if (status.isDirectory()) {
				throw new Error(`${path} is a directory`);
			}

			offset ??= 0;
			length ??= buf.length;
			length = Math.min(length, buf.length);
			const end = offset + length;
			pos = Math.max(position ?? pos, 0);
			const oldPos = pos;

			const nameAndPath = getNameAndPath(path);
			const result = await client.query(
				`SELECT substring("content" FROM $3 FOR $4) AS "buffer"
					FROM "db_files"
					WHERE "name" = $1 AND "path" = $2;
				`, [nameAndPath.name, nameAndPath.path, pos, length]);

			const buffer = result.rows[0]?.buffer ?? [];

			for (let i = offset; i < end && i < buffer.length; ++i) {
				buf[i] = buffer[i];
			}

			return {
				buffer: buf,
				butesRead: pos - oldPos,
			};
		},
		readFile: () => this.readFile(path),
		close() {

		}
	};
}