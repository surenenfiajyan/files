function testWebSocket() {
	const url = new URL(document.location.href);
	url.protocol = url.protocol === 'https:' ? 'wss' : 'ws';
	url.pathname = 'test-ws';
	url.search = '';

	const socket = new WebSocket(url);

	socket.addEventListener("open", (event) => {
		const interval = setInterval(() => {
			if (socket.readyState === socket.OPEN) {
				socket.send(Math.random());
			} else {
				clearInterval(interval);
			}
		}, 1000);
	});

	socket.addEventListener("message", (event) => {
		if (+event.data < 0.1) {
			socket.close();
		}
	});
}

//testWebSocket();

function addClipboardclickListeners() {
	document.querySelectorAll('.f_copyToClipboard').forEach(el => {
		el.onclick = () => {
			navigator.clipboard.writeText(el.closest('.image-block').querySelector('[src]').src);
			setTimeout(() => alert('Done'), 100);
		};
	});
}


const imageBlockTemplate = document.getElementById('imageBlockTemplate');
const videoBlockTemplate = document.getElementById('videoBlockTemplate');
const audioBlockTemplate = document.getElementById('audioBlockTemplate');

function refreshUi(data) {
	if (!data.images.length) {
		document.location.reload();
		return;
	}

	const currentBlocks = new Map(data.images.map(x => [x.id, x]));
	const oldblocks = new Map([...document.querySelectorAll('.image-block')].map(x => [x.id, x]));

	for (const [id, oldEl] of oldblocks) {
		if (!currentBlocks.has(id)) {
			oldEl.remove();
		}
	}

	const elementsToAdd = [];

	for (const [id, currentData] of currentBlocks) {
		if (!oldblocks.has(id)) {
			const newEl = (currentData.isVideo ? videoBlockTemplate : (currentData.isAudio ? audioBlockTemplate : imageBlockTemplate)).content.querySelector('.image-block').cloneNode(true);
			newEl.id = id;
			newEl.querySelector('[src]').src = currentData.url;
			newEl.querySelector('[formaction]').formAction = `/delete-image/${id}`;
			elementsToAdd.push(newEl);
		}
	}

	document.querySelector('.images-container').append(...elementsToAdd);

	if (currentBlocks.size < 50) {
		document.getElementById('uploadForm').style.display = '';
	} else {
		document.getElementById('uploadForm').style.display = 'none';
	}

	addClipboardclickListeners();
}

if (imageBlockTemplate && videoBlockTemplate && audioBlockTemplate) {
	addClipboardclickListeners();

	window.addEventListener('click', e => {
		const button = e.target;

		if (!(button instanceof HTMLButtonElement)) {
			return;
		}

		const closestWithAction = button.closest('[formaction], [action]');
		const action = closestWithAction?.action ?? closestWithAction?.formAction;

		if (!action) {
			return;
		}

		const url = new URL(action);

		const isImagesAdd = url.pathname.includes('/add-images');
		const isImageDelete = url.pathname.includes('/delete-image');


		if (!isImagesAdd && !isImageDelete) {
			return;
		}

		if (isImageDelete && document.querySelectorAll('.f_copyToClipboard').length <= 1) {
			return;
		}

		if (isImagesAdd && !closestWithAction.querySelector('input').value) {
			return;
		}

		url.searchParams.append('isJson', '1');
		e.preventDefault();

		async function makeRequests() {
			try {
				document.activeElement?.blur();
				document.querySelectorAll('a, button, input').forEach(el => el.tabIndex = -1);
				document.body.classList.add('loading');

				if (isImageDelete) {
					const result = await fetch(url, { method: 'post' });
					const data = await result.json();
					refreshUi(data);
					return;
				}

				const body = new FormData(closestWithAction);
				const result = await fetch(url, { method: 'post', body });
				const data = await result.json();
				refreshUi(data);
				closestWithAction.reset();
			} finally {
				document.querySelectorAll('a, button, input').forEach(el => el.removeAttribute('tabindex'));
				document.body.classList.remove('loading');
			}
		}

		makeRequests();
	});
}